README for GRB-28172_B.zip

Company Part Number: 170-28172 REV B

Date : Wed, 26 Feb 2014 07:08:13 GMT

Freescale Semiconductor
6501 William Cannon Drive West
Austin, TX 78735-8598

Company Contact: Clara Li
	Work Phone: +86-21-2893 7043
		 Email:	 clara.li@freescale.com